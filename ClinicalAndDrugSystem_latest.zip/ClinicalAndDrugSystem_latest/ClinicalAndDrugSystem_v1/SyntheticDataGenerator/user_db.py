"""
user_db.py

Handles user authentication and management using a local SQLite database.
Passwords are securely hashed using bcrypt.
"""

import sqlite3
import bcrypt
import os
from typing import Dict, Optional, List
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "users.db")


def get_db_connection():
    """Creates a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def hash_password(password: str) -> bytes:
    """Hashes a password for storing."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())


def check_password(password: str, hashed_password: bytes) -> bool:
    """Checks a password against a stored hash."""
    return bcrypt.checkpw(password.encode("utf-8"), hashed_password)


def init_db():
    """Initializes the database and creates the users table if it doesn't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash BLOB NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            username TEXT NOT NULL,
            patient_id TEXT,
            query TEXT NOT NULL,
            final_answer TEXT NOT NULL
        )
        """
    )

    # Check if any users exist
    cursor.execute("SELECT COUNT(*) FROM users")
    user_count = cursor.fetchone()[0]

    # If no users, populate with default users
    if user_count == 0:
        print("Database is empty. Populating with default users...")
        default_users = [
            ("clinician1", "password123", "Dr. Evelyn Reed", "Clinician"),
            ("admin1", "adminpass", "Admin User", "Admin"),
        ]
        for username, password, name, role in default_users:
            cursor.execute(
                "INSERT INTO users (username, password_hash, name, role) VALUES (?, ?, ?, ?)",
                (username, hash_password(password), name, role),
            )
        print("Default users created.")

    conn.commit()
    conn.close()


def verify_user(username: str, password: str) -> Optional[Dict]:
    """Verifies user credentials against the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user_row = cursor.fetchone()
    conn.close()

    if user_row and check_password(password, user_row["password_hash"]):
        return dict(user_row)

    return None


def create_user(username: str, password: str, name: str, role: str) -> str:
    """Creates a new user in the database. Returns a status message."""
    if not all([username, password, name, role]):
        return "Error: All fields are required."

    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if username already exists
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        conn.close()
        return f"Error: Username '{username}' already exists."

    try:
        cursor.execute(
            "INSERT INTO users (username, password_hash, name, role) VALUES (?, ?, ?, ?)",
            (username, hash_password(password), name, role),
        )
        conn.commit()
        message = f"Success: User '{username}' created."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()

    return message


def list_users() -> List[Dict]:
    """Lists all users from the database, excluding password hash."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, name, role FROM users")
    users = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return users

def get_user_by_id(user_id: int) -> Optional[Dict]:
    """Gets a single user by their ID."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, name, role FROM users WHERE id = ?", (user_id,))
    user_row = cursor.fetchone()
    conn.close()
    return dict(user_row) if user_row else None


def update_user(user_id: int, name: str, role: str, password: Optional[str] = None) -> str:
    """Updates a user's name, role, and optionally their password."""
    if not all([name, role]):
        return "Error: Name and role fields are required."

    conn = get_db_connection()
    cursor = conn.cursor()

    # Prevent changing the role of the last admin
    cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
    current_user = cursor.fetchone()
    if current_user and current_user["role"] == "Admin" and role != "Admin":
        cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
        admin_count = cursor.fetchone()[0]
        if admin_count <= 1:
            conn.close()
            return "Error: Cannot change the role of the last admin user."

    try:
        if password:
            # Update with new password
            password_hash = hash_password(password)
            cursor.execute("UPDATE users SET name = ?, role = ?, password_hash = ? WHERE id = ?", (name, role, password_hash, user_id))
        else:
            # Update without changing password
            cursor.execute("UPDATE users SET name = ?, role = ? WHERE id = ?", (name, role, user_id))
        conn.commit()
        message = f"Success: User ID {user_id} updated."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()
    return message

def add_audit_log_entry(username: str, patient_id: Optional[str], query: str, final_answer: str):
    """Adds a new entry to the audit log."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT INTO audit_log (timestamp, username, patient_id, query, final_answer)
            VALUES (?, ?, ?, ?, ?)
            """,
            (datetime.utcnow().isoformat(), username, patient_id, query, final_answer),
        )
        conn.commit()
    except sqlite3.Error as e:
        print(f"Database error while logging: {e}")
    finally:
        conn.close()


def get_audit_logs(limit: int, offset: int) -> List[Dict]:
    """Retrieves a page of audit log entries, most recent first."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ? OFFSET ?", (limit, offset))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs


def delete_user(user_id: int) -> str:
    """Deletes a user from the database by their ID."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Prevent deleting the last admin
    cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
    user_to_delete = cursor.fetchone()
    if user_to_delete and user_to_delete["role"] == "Admin":
        cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
        admin_count = cursor.fetchone()[0]
        if admin_count <= 1:
            conn.close()
            return "Error: Cannot delete the last admin user."

    try:
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        if cursor.rowcount > 0:
            message = f"Success: User with ID {user_id} deleted."
        else:
            message = f"Error: No user found with ID {user_id}."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()

    return message



def get_audit_log_count() -> int:
    """Returns the total number of audit log entries."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM audit_log")
    count = cursor.fetchone()[0]
    conn.close()
    return count