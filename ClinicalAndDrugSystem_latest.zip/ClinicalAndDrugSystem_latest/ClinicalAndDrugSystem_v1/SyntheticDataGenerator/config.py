# """
# config.py

# Global configuration + OpenAI client setup for the Clinical LangGraph System.
# Supports:
# - Normal OpenAI API
# - Enterprise Gateway (e.g., TCS GenAI Lab)
# - Secure env loading
# - Embedding + Chat model configs
# """

# import os
# from dotenv import load_dotenv
# from openai import OpenAI
# import httpx


# # ---------------------------------------------------------
# # Load environment variables
# # ---------------------------------------------------------
# load_dotenv()

# API_KEY = os.getenv("OPENAI_API_KEY")
# if not API_KEY:
#     raise RuntimeError("❌ OPENAI_API_KEY is not set in your environment (.env file).")

# # Optional Enterprise Gateway / Azure Gateway URL
# BASE_URL = os.getenv("OPENAI_BASE_URL")  # e.g., https://genailab.tcs.in

# # ---------------------------------------------------------
# # Initialize OpenAI Client
# # ---------------------------------------------------------
# if BASE_URL:
#     # For TCS / Azure internal gateway (bypass SSL check if needed)
#     client = OpenAI(
#         api_key=API_KEY,
#         base_url=BASE_URL,
#         http_client=httpx.Client(verify=False),
#     )
# else:
#     # Standard OpenAI endpoint
#     client = OpenAI(api_key=API_KEY)


# # ---------------------------------------------------------
# # Model Configuration
# # ---------------------------------------------------------

# # LLM model for chat-based agents
# MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")

# # Embedding model (you wanted)
# EMBEDDING_MODEL = os.getenv(
#     "OPENAI_EMBEDDING_MODEL",
#     "text-embedding-3-large",  # Standard OpenAI embedding model
# )
"""
config.py

Global configuration + OpenAI client setup for the Clinical LangGraph System.
Supports:
- Normal OpenAI API
- Enterprise Gateway (e.g., TCS GenAI Lab)
- Secure env loading
- Embedding + Chat model configs
"""

import os
from dotenv import load_dotenv
from openai import OpenAI
import httpx


# ---------------------------------------------------------
# Load environment variables
# ---------------------------------------------------------
load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")
if not API_KEY:
    raise RuntimeError("❌ OPENAI_API_KEY is not set in your environment (.env file).")

# Optional Enterprise Gateway / Azure Gateway URL
BASE_URL = os.getenv("OPENAI_BASE_URL")  # e.g., https://genailab.tcs.in

# ---------------------------------------------------------
# Initialize OpenAI Client
# ---------------------------------------------------------
if BASE_URL:
    # For TCS / Azure internal gateway (bypass SSL check if needed)
    client = OpenAI(
        api_key=API_KEY,
        base_url=BASE_URL,
        http_client=httpx.Client(verify=False),
    )
else:
    # Standard OpenAI endpoint
    client = OpenAI(api_key=API_KEY)


# ---------------------------------------------------------
# Model Configuration
# ---------------------------------------------------------

# LLM model for chat-based agents
MODEL = os.getenv("OPENAI_MODEL", "azure/genailab-maas-gpt-4o")

# Embedding model (you wanted)
EMBEDDING_MODEL = os.getenv(
    "OPENAI_EMBEDDING_MODEL",
    "azure/genailab-maas-text-embedding-3-large",
)

# ---------------------------------------------------------
# Optional: Debug Toggle
# ---------------------------------------------------------
DEBUG = os.getenv("DEBUG", "false").lower() == "true"

# ---------------------------------------------------------
# Service URLs
# ---------------------------------------------------------
MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://127.0.0.1:8000")
