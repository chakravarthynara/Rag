from typing import Optional, Dict, Any, List
import streamlit as st
import io

from clinical_data import ClinicalDataStore
from user_db import init_db, verify_user, list_users, create_user, add_audit_log_entry, get_audit_logs, get_audit_log_count, delete_user, get_user_by_id, update_user
from config import client as openai_client
from graph_workflow import run_workflow, risk_prediction_agent


# -------------------------------------------------------------
# WORKFLOW EXECUTION
# -------------------------------------------------------------
def run_clinical_workflow(query: str, patient_id: Optional[str], username: str) -> str:
    """
    Runs the LangGraph workflow and returns the clinician-facing summary.
    """
    if not query.strip():
        return "Please enter a clinical question."

    state: Dict[str, Any] = run_workflow(query, patient_id or None)
    final_answer = state.get(
        "final_answer",
        "No final answer produced. Please check backend / logs.",
    )

    # Log the query and response to the database
    add_audit_log_entry(username=username, patient_id=patient_id, query=query, final_answer=final_answer)

    return final_answer


def transcribe_audio(audio_bytes: bytes) -> str:
    """
    Transcribes audio bytes using OpenAI's Whisper model.
    """
    if not audio_bytes:
        return ""
    try:
        audio_file = io.BytesIO(audio_bytes)
        audio_file.name = "voice_query.wav"  # The API needs a file name

        transcript = openai_client.audio.transcriptions.create(
            model="whisper-1",
            file=audio_file,
        )
        return transcript.text
    except Exception as e:
        st.error(f"Audio transcription failed: {e}")
        return ""


# -------------------------------------------------------------
# PATIENT FORM HELPERS
# -------------------------------------------------------------
def load_patient_for_edit(selected_id: Optional[str]) -> List[str]:
    """
    Load an existing patient into the edit form.
    Returns 6 fields in order:
    [patient_id, age, gender, allergies, conditions, medications]
    """
    if not selected_id:
        return ["", "", "", "", "", ""]

    # Fetch the full context to get all related data
    ctx = ClinicalDataStore.get_patient_context(selected_id) or {}
    row = ctx.get("patient", {})

    # Extract and format lists as comma-separated strings for the form
    allergies_list = [a.get("allergen", "") for a in ctx.get("allergies", []) if a.get("allergen")]
    conditions_list = [c.get("condition_name", "") for c in ctx.get("conditions", []) if c.get("condition_name")]
    meds_list = [m.get("drug_name", "") for m in ctx.get("medications", []) if m.get("drug_name")]

    allergies_str = ", ".join(filter(None, allergies_list))
    conditions_str = ", ".join(filter(None, conditions_list))
    meds_str = ", ".join(filter(None, meds_list))

    return [
        row.get("patient_id", selected_id),
        str(row.get("age", "")),
        row.get("gender", ""),
        allergies_str,
        conditions_str,
        meds_str,
    ]


def on_patient_dropdown_change(selected_id: Optional[str]):
    """
    When user selects a patient:
    - load details into the form
    - update current patient badges
    - keep the original id for rename cascade
    - Returns blank string to clear the analysis output.
    """
    (
        pid,
        age,
        gender,
        allergies,
        conditions,
        meds,
    ) = load_patient_for_edit(selected_id)

    if selected_id:
        badge_main = f"Demo Patient: **{selected_id}**"
        badge_workspace = f"Current Patient: **{selected_id}**"
    else:
        badge_main = "Demo Patient: –"
        badge_workspace = "Current Patient: –"

    original_id = selected_id or ""

    # 6 form fields + header badge + workspace badge + hidden original id + CLEAR OUTPUT
    return (
        pid,
        age,
        gender,
        allergies,
        conditions,
        meds,
        badge_main,
        badge_workspace,
        original_id,
        "",  # Clear final answer
    )


def save_patient(
    original_patient_id: str,
    patient_id: str,
    age: str,
    gender: str,
    allergies: str,
    conditions: str,
    medications: str,
):
    """
    Upsert patient into patients.csv.
    Returns same semantics as before but adapted for Streamlit:
    (status, ids_list, badge_main, badge_workspace, new_original_id, cleared_output)
    """
    if not patient_id.strip():
        return (
            "❌ Patient ID is required.",
            ClinicalDataStore.list_patient_ids(),  # keep dropdown choices as-is
            "Demo Patient: –",
            "Current Patient: –",
            original_patient_id,
            "",  # Clear output on error
        )

    new_id = patient_id.strip()
    orig_id = (original_patient_id or "").strip()

    # 1) Rename cascade if needed
    if orig_id and orig_id != new_id:
        ClinicalDataStore.rename_patient_id(orig_id, new_id)

    # 2) Upsert patient row
    ClinicalDataStore.upsert_patient(
        {
            "patient_id": new_id,
            "age": age.strip(),
            "gender": gender.strip(),
            "allergies": allergies.strip(),
            "conditions": conditions.strip(),
            "medications": medications.strip(),
        }
    )

    # 3) Refresh dropdown
    ids = ClinicalDataStore.list_patient_ids()

    badge_main = f"Demo Patient: **{new_id}**"
    badge_workspace = f"Current Patient: **{new_id}**"

    return (
        "✅ Patient saved/updated.",
        ids,
        badge_main,
        badge_workspace,
        new_id,  # new original id
        "",  # Clear output on save
    )


def clear_query_and_output():
    """Returns empty strings to clear the query box and the output box."""
    return "", ""


# -------------------------------------------------------------
# CUSTOM CSS (keep your styling ideas, adapted for Streamlit)
# -------------------------------------------------------------
CUSTOM_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');

body {
    background-image: url("https://www.toptal.com/designers/subtlepatterns/uploads/double-bubble-outline.png");
    background-color: #020617; /* Fallback color */
    background-size: auto;
    font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #e5e7eb;
}
.main-container {
    /* max-width is removed to allow full-width layout */
}

/* HEADER + BADGES */
.badge-row {
    display: flex;
    justify-content: flex-end;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
}
.badge-pill {
    background: #0f172a;
    border-radius: 999px;
    padding: 0.35rem 0.9rem;
    border: 1px solid #1e293b;
    font-size: 0.8rem;
    color: #94a3b8;
}

/* FINAL ANSWER BOX */
#final_answer_markdown {
    max-height: 450px;
    overflow-y: auto;
    background-color: #0d1421;
    border: 1px solid #374151;
    padding: 15px;
    border-radius: 8px;
    color: #e5e7eb;
}
#final_answer_markdown h3 {
    color: #fca5a5;
    border-bottom: 1px solid #475569;
}
#final_answer_markdown h4 {
    color: #22c55e;
}
#final_answer_markdown strong {
    color: #5eead4;
}

/* Make Streamlit text inputs a bit more compact */
div.stTextInput input, div.stSelectbox select {
    height: 34px;
    padding: 4px 8px;
    font-size: 0.9rem;
}
div.stTextArea textarea {
    min-height: 110px;
    font-size: 0.9rem;
}
"""


# -------------------------------------------------------------
# STREAMLIT APP
# -------------------------------------------------------------
def main():
    # Initialize the user database on first run
    init_db()

    # --- LOGIN LOGIC ---
    if "user_info" not in st.session_state:
        st.session_state.user_info = None

    if st.session_state.user_info is None:
        render_login_page()
    else:
        render_main_app()


def render_login_page():
    st.set_page_config(page_title="Clinical AI Login", layout="centered")
    st.markdown(f"<style>{CUSTOM_CSS}</style>", unsafe_allow_html=True)

    st.markdown("<h1 style='text-align: center; color:#5eead4;'>Clinical AI Assistant Login</h1>", unsafe_allow_html=True)

    with st.form("login_form"):
        username = st.text_input("Username", key="login_username")
        password = st.text_input("Password", type="password", key="login_password")
        submitted = st.form_submit_button("Login")

        if submitted:
            user = verify_user(username, password)
            if user:
                st.session_state.user_info = {
                    "username": username,
                    "name": user["name"],
                    "role": user["role"],
                }
                st.rerun()
            else:
                st.error("Invalid username or password")


def render_main_app():
    st.set_page_config(page_title="Clinical AI Assistant", layout="wide")
    st.markdown(f"<style>{CUSTOM_CSS}</style>", unsafe_allow_html=True)

    # Recompute patient IDs each run (reflects any new saves)
    patient_ids = ClinicalDataStore.list_patient_ids()

    # ------------- INITIAL SESSION STATE (MUST BE FIRST) -------------
    # Initialize all session state keys used in the app
    app_state_keys = [
        "selected_patient_id", "patient_action", "next_selected_patient_id",
        "risk_prediction_result", "last_selected_patient_id", "patient_id",
        "age", "gender", "allergies", "conditions", "medications",
        "original_patient_id", "demo_patient_badge", "current_patient_badge", "log_page_number", "editing_user_id",
        "final_answer", "save_status", "query"
    ]
    for key in app_state_keys:
        if key not in st.session_state:
            st.session_state[key] = None # Initialize with a default

    if "selected_patient_id" not in st.session_state:
        st.session_state.selected_patient_id = patient_ids[0] if patient_ids else ""

    if "patient_action" not in st.session_state:
        st.session_state.patient_action = "Select Existing Patient"
    
    if "next_selected_patient_id" not in st.session_state:
        st.session_state.next_selected_patient_id = None

    if "risk_prediction_result" not in st.session_state:
        st.session_state.risk_prediction_result = None

    if "last_selected_patient_id" not in st.session_state:
        st.session_state.last_selected_patient_id = st.session_state.selected_patient_id
    
    if "log_page_number" not in st.session_state or st.session_state.log_page_number is None:
        st.session_state.log_page_number = 0

    if "editing_user_id" not in st.session_state:
        st.session_state.editing_user_id = None
    
    if st.session_state.get("next_selected_patient_id"):
        # Set the main state variable BEFORE the widget is instantiated
        st.session_state.selected_patient_id = st.session_state.next_selected_patient_id
        st.session_state.next_selected_patient_id = None # Clear the temporary variable

    # Initialize form fields from the current selected patient at first load
    if "patient_id" not in st.session_state:
        (
            pid,
            age,
            gender,
            allergies,
            conditions,
            meds,
            badge_main,
            badge_workspace,
            original_id,
            cleared,
        ) = on_patient_dropdown_change(st.session_state.selected_patient_id or None)
        st.session_state.patient_id = pid
        st.session_state.age = age
        st.session_state.gender = gender
        st.session_state.allergies = allergies
        st.session_state.conditions = conditions
        st.session_state.medications = meds
        st.session_state.original_patient_id = original_id
        st.session_state.demo_patient_badge = badge_main
        st.session_state.current_patient_badge = badge_workspace
        st.session_state.final_answer = cleared
        st.session_state.save_status = ""

    if "query" not in st.session_state:
        st.session_state.query = ""
    if "final_answer" not in st.session_state:
        st.session_state.final_answer = ""
    if "save_status" not in st.session_state:
        st.session_state.save_status = ""
    if "demo_patient_badge" not in st.session_state:
        st.session_state.demo_patient_badge = "Demo Patient: –"
    if "current_patient_badge" not in st.session_state:
        st.session_state.current_patient_badge = "Current Patient: –"

    # ---------------- HEADER ----------------
    logo_col, title_col = st.columns([1, 10])
    with logo_col:
        # A simple SVG logo embedded as a data URI
        st.markdown("""
            <svg width="60" height="60" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" fill="#5eead4" fill-opacity="0.3"/>
                <path d="M4 12H7L9 9L11 15L13 11L15 13H20" stroke="#5eead4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        """, unsafe_allow_html=True)
    with title_col:
        st.markdown(
            """
            <h1 style="color:#5eead4; margin-top: -10px;">Clinical AI Assistant</h1>
            """,
            unsafe_allow_html=True,
        )
    
    st.markdown("""
        <p style="font-size:0.9rem; color:#94a3b8;">
        ⚠ This system uses <strong>synthetic/LLM-generated reasoning</strong> and data. It is for demonstration and learning only — <strong>not real medical advice</strong>.
        </p>
    """, unsafe_allow_html=True)

    st.markdown('<div class="badge-row">', unsafe_allow_html=True)
    col_b1, col_b2, col_b3, col_b4 = st.columns([2, 2, 2, 1])
    with col_b1:
        st.markdown(
            f'<div class="badge-pill">👤 Welcome, <strong>{st.session_state.user_info["name"]}</strong> ({st.session_state.user_info["role"]})</div>',
            unsafe_allow_html=True,
        )
    with col_b2:
        st.markdown(
            f'<div class="badge-pill">{st.session_state.get("demo_patient_badge", "Demo Patient: –")}</div>',
            unsafe_allow_html=True,
        )
    with col_b3:
        st.markdown(
            '<div class="badge-pill">🟡 <strong>Simulation Mode</strong></div>',
            unsafe_allow_html=True,
        )
    with col_b4:
        if st.button("Logout", key="logout_button"):
            st.session_state.user_info = None
            st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

    # --- TABS FOR MAIN APP AND ADMIN VIEW ---
    main_tab_list = ["Clinical Workspace"]
    is_admin = st.session_state.user_info["role"] == "Admin"

    if is_admin:
        main_tab_list.append("Admin Panel")

    tab1, *admin_tabs = st.tabs(main_tab_list)

    with tab1:
        # ------------- TOP: CONTEXT + WORKSPACE -------------
        col_left, col_right = st.columns([1, 2])

        # LEFT: Patient Context
        with col_left:
            st.markdown("### 👤 Patient Context")

            # Action selection
            st.radio(
                "Patient Management",
                ["Select Existing Patient", "Create / Update Patient"],
                key="patient_action",
            )

            st.markdown("---")

            if st.session_state.patient_action == "Select Existing Patient":
                st.markdown("#### Select Patient to View Details")
                selected_id_display = st.selectbox(
                    "Select Patient ID",
                    options=[""] + patient_ids,
                    index=0,
                    key="display_patient_id",
                )
                if selected_id_display:
                    # Use get_patient_context to fetch all related data, not just the main row
                    ctx = ClinicalDataStore.get_patient_context(selected_id_display)
                    if ctx:
                        patient_row = ctx.get("patient", {})
                        allergies_list = [a.get("allergen", "") for a in ctx.get("allergies", []) if a.get("allergen")]
                        conditions_list = [c.get("condition_name", "") for c in ctx.get("conditions", []) if c.get("condition_name")]
                        meds_list = [m.get("drug_name", "") for m in ctx.get("medications", []) if m.get("drug_name")]

                        allergies_str = ", ".join(filter(None, allergies_list)) or "None"
                        conditions_str = ", ".join(filter(None, conditions_list)) or "None"
                        meds_str = ", ".join(filter(None, meds_list)) or "None"

                    # FIX: Update the workspace badge when viewing a patient
                    st.session_state.current_patient_badge = f"Current Patient: **{selected_id_display}**"

                    st.markdown(f"**Patient ID:** `{patient_row.get('patient_id', 'N/A')}`")
                    st.markdown(f"**Age:** {patient_row.get('age', 'N/A')}")
                    st.markdown(f"**Gender:** {patient_row.get('gender', 'N/A')}")
                    st.markdown("**Known Allergies:**")
                    st.markdown(f"> {allergies_str}")
                    st.markdown("**Medical Conditions:**")
                    st.markdown(f"> {conditions_str}")
                    st.markdown("**Current Medications:**")
                    st.markdown(f"> {meds_str}")

            elif st.session_state.patient_action == "Create / Update Patient":
                st.markdown("#### Create or Edit Patient Details")
                # Patient dropdown for editing
                st.selectbox(
                    "Load Existing Patient to Edit (optional)",
                    options=[""] + patient_ids,
                    key="selected_patient_id",
                )

                # Detect change in selection
                if st.session_state.selected_patient_id != st.session_state.last_selected_patient_id:
                    (
                        pid, age, gender, allergies, conditions, meds,
                        badge_main, badge_workspace, original_id, cleared
                    ) = on_patient_dropdown_change(st.session_state.selected_patient_id or None)

                    st.session_state.patient_id = pid
                    st.session_state.age = age
                    st.session_state.gender = gender
                    st.session_state.allergies = allergies
                    st.session_state.conditions = conditions
                    st.session_state.medications = meds
                    st.session_state.original_patient_id = original_id
                    st.session_state.demo_patient_badge = badge_main
                    st.session_state.current_patient_badge = badge_workspace
                    st.session_state.final_answer = cleared
                    st.session_state.save_status = ""
                    st.session_state.last_selected_patient_id = st.session_state.selected_patient_id

                # Form fields
                col_pid, col_age = st.columns(2)
                with col_pid:
                    st.text_input("Patient ID*", key="patient_id")
                with col_age:
                    st.text_input("Age", key="age")

                st.selectbox("Gender", options=["Male", "Female", "Other"], key="gender")

                st.text_input("Known Allergies", placeholder="e.g., Penicillin, Sulfa", key="allergies")
                st.text_input("Medical Conditions", placeholder="e.g., Hypertension, Diabetes", key="conditions")
                st.text_input("Current Medications", placeholder="e.g., Aspirin, Metformin", key="medications")

                if st.button("Save / Update Patient"):
                    (
                        status_msg, ids_after, badge_main, badge_workspace,
                        new_orig_id, cleared
                    ) = save_patient(
                        st.session_state.original_patient_id,
                        st.session_state.patient_id,
                        st.session_state.age,
                        st.session_state.gender,
                        st.session_state.allergies,
                        st.session_state.conditions,
                        st.session_state.medications,
                    )
                    st.session_state.save_status = status_msg
                    # Use an intermediary state variable to set the value on the next run
                    st.session_state.next_selected_patient_id = new_orig_id
                    st.session_state.original_patient_id = new_orig_id
                    st.session_state.demo_patient_badge = badge_main
                    st.session_state.current_patient_badge = badge_workspace
                    st.session_state.final_answer = cleared
                    st.rerun()

                if st.session_state.save_status:
                    st.markdown(st.session_state.save_status)

            st.markdown("---")
            st.markdown("#### 📈 Predictive Risk Models")

            risk_model_options = [
                "1-year major adverse cardiovascular event (MACE)",
                "5-year risk of developing Type 2 Diabetes",
            "ML-based Health Risk Score",
                "30-day hospital readmission risk",
            ]
            selected_risk_model = st.selectbox(
                "Select a Synthetic Risk Model",
                options=risk_model_options,
                index=0,
            )

            if st.button("Calculate Risk"):
                patient_to_assess = st.session_state.get('display_patient_id') or st.session_state.get('selected_patient_id')
                if patient_to_assess:
                    with st.spinner("Calculating risk..."):
                        if selected_risk_model == "ML-based Health Risk Score":
                            result = risk_prediction_agent.predict_risk_ml(patient_to_assess)
                        else:
                            result = risk_prediction_agent.predict_risk(patient_to_assess, selected_risk_model)
                    st.session_state.risk_prediction_result = result
                else:
                    st.warning("Please select a patient first.")

            if st.session_state.risk_prediction_result:
                res = st.session_state.risk_prediction_result
                if "error" in res:
                    st.error(f"Error calculating risk: {res['error']}")
                else:
                    qual_risk = res.get('qualitative_risk', 'N/A')
                    quant_risk = res.get('quantitative_risk_percent', 'N/A')
                    st.metric(label=f"Qualitative Risk ({res.get('risk_topic')})", value=qual_risk)
                    st.progress(float(quant_risk) / 100.0 if isinstance(quant_risk, (int, float)) else 0.0, text=f"{quant_risk}%")

                    with st.expander("View Risk Factors and Explanation"):
                        st.markdown("**Key Contributing Risk Factors:**")
                        factors = res.get('key_risk_factors', [])
                        for factor in factors:
                            st.markdown(f"- {factor}")
                        st.markdown("**Explanation:**")
                        st.markdown(f"> {res.get('explanation', 'No explanation provided.')}")


        # RIGHT: Clinical Reasoning Workspace
        with col_right:
            st.markdown("### 🩺 Clinical Reasoning Workspace")
            st.markdown(st.session_state.get("current_patient_badge", "Current Patient: –"))

            st.markdown(
                "Route your free-text clinical question to the multi-agent workflow. "
                "Agents will use patient context plus synthetic data."
            )

            # --- Voice Query Input ---
            from streamlit_mic_recorder import mic_recorder
            st.markdown("##### Voice Query (hands-free)")
            
            audio_info = mic_recorder(
                start_prompt="🎤 Start Recording",
                stop_prompt="⏹️ Stop Recording",
                key='mic_recorder'
            )

            if audio_info and audio_info['bytes']:
                with st.spinner("Transcribing audio..."):
                    transcribed_text = transcribe_audio(audio_info['bytes'])
                    if transcribed_text:
                        st.session_state.query = transcribed_text
                        # Automatically run analysis after transcription
                        with st.spinner("Running analysis on transcribed query..."):
                            answer = run_clinical_workflow(
                                st.session_state.query,
                                st.session_state.get('display_patient_id') or st.session_state.get('selected_patient_id') or None,
                                st.session_state.user_info["username"],
                            )
                            st.session_state.final_answer = answer
                            st.rerun() # Rerun to update the UI with the new query and answer

            st.text_area(
                "Clinical Question",
                placeholder='e.g., "Can I safely combine warfarin and aspirin for this patient?"',
                key="query",
                height=120,
            )

            col_run, col_clear = st.columns(2)
            with col_run:
                if st.button("Analyze Query"):
                    answer = run_clinical_workflow(
                        st.session_state.query,
                        st.session_state.get('display_patient_id') or st.session_state.get('selected_patient_id') or None,
                        st.session_state.user_info["username"],
                    )
                    st.session_state.final_answer = answer
            # with col_clear:
            #     if st.button("Clear"):
            #         q, out = clear_query_and_output()
            #         st.session_state.query = q
            #         st.session_state.final_answer = out
            
            st.markdown("---")

            # --- ANALYSIS RESULT (MOVED HERE) ---
            st.markdown("### 📋 Clinical Analysis Result")

            st.warning(
                "**Disclaimer:** The following analysis is generated by an AI model using "
                "synthetic data. It is for demonstration purposes only and is **not** a substitute for professional medical advice."
            )

            if st.session_state.final_answer:
                st.markdown(
                    f"<div id='final_answer_markdown'>{st.session_state.final_answer}</div>",
                    unsafe_allow_html=True,
                )
            else:
                st.info("Analysis results will appear here after clicking **Analyze Query**.")

    if is_admin:
        with admin_tabs[0]:
            admin_tab_log, admin_tab_users = st.tabs(["Audit Log", "User Management"])

            with admin_tab_log:
                st.markdown("### 📝 Audit Log")
                st.markdown("This log shows all clinical queries and their final summarized responses from the database.")

                # --- Pagination Logic ---
                LOGS_PER_PAGE = 10
                total_logs = get_audit_log_count()
                total_pages = (total_logs + LOGS_PER_PAGE - 1) // LOGS_PER_PAGE

                if total_logs == 0:
                    st.info("No queries have been logged in the database yet.")
                else:
                    # Pagination controls
                    col1, col2, col3 = st.columns([1, 2, 1])
                    with col1:
                        if st.button("⬅️ Previous", disabled=(st.session_state.log_page_number == 0)):
                            st.session_state.log_page_number -= 1
                    with col2:
                        st.write(f"Page {st.session_state.log_page_number + 1} of {total_pages}")
                    with col3:
                        if st.button("Next ➡️", disabled=(st.session_state.log_page_number >= total_pages - 1)):
                            st.session_state.log_page_number += 1

                    # Fetch and display logs for the current page
                    offset = st.session_state.log_page_number * LOGS_PER_PAGE
                    log_entries = get_audit_logs(limit=LOGS_PER_PAGE, offset=offset)

                    for entry in log_entries:
                        with st.expander(f"Log ID {entry['id']} @ {entry['timestamp']} by {entry['username']} (Patient: {entry.get('patient_id', 'N/A')})"):
                            st.markdown(f"**Query:**\n\n> {entry['query']}")
                            st.markdown(f"**Summarized Response:**\n\n> {entry['final_answer']}")


            with admin_tab_users:
                st.markdown("### 👥 User Management")
                st.markdown("View, create, edit, or delete users.")

                st.subheader("Existing Users")
                all_users = list_users()
                
                # Display header
                cols = st.columns([1, 2, 3, 2, 3])
                cols[0].write("**ID**")
                cols[1].write("**Username**")
                cols[2].write("**Name**")
                cols[3].write("**Role**")
                cols[4].write("**Actions**")
                st.markdown("---")

                for user in all_users:
                    user_id, username, name, role = user["id"], user["username"], user["name"], user["role"]
                    cols = st.columns([1, 2, 3, 2, 3])
                    cols[0].write(user_id)
                    cols[1].write(username)
                    cols[2].write(name)
                    cols[3].write(role)
                    
                    action_col = cols[4]
                    # Prevent admin from deleting or editing their own role away from admin
                    is_self = user["username"] == st.session_state.user_info["username"]

                    if action_col.button("Edit", key=f"edit_{user_id}"):
                        st.session_state.editing_user_id = user_id
                        st.rerun()

                    if action_col.button("Delete", key=f"delete_{user_id}", disabled=is_self):
                        delete_status = delete_user(user_id)
                        st.toast(delete_status)
                        st.rerun()

                st.markdown("---")

                # --- Edit or Create Form ---
                if st.session_state.editing_user_id:
                    user_to_edit = get_user_by_id(st.session_state.editing_user_id)
                    if user_to_edit:
                        st.subheader(f"Edit User: {user_to_edit['username']} (ID: {user_to_edit['id']})")
                        with st.form("edit_user_form"):
                            edit_name = st.text_input("Full Name", value=user_to_edit['name'])
                            edit_role = st.selectbox("Role", ["Clinician", "Admin"], index=["Clinician", "Admin"].index(user_to_edit['role']))
                            edit_password = st.text_input("New Password (optional)", type="password", placeholder="Leave blank to keep current password")
                            
                            save_col, cancel_col = st.columns(2)
                            if save_col.form_submit_button("Save Changes"):
                                status = update_user(user_to_edit['id'], edit_name, edit_role, edit_password or None)
                                st.toast(status)
                                st.session_state.editing_user_id = None
                                st.rerun()
                            if cancel_col.form_submit_button("Cancel", type="secondary"):
                                st.session_state.editing_user_id = None
                                st.rerun()
                else:
                    st.subheader("Create New User")
                    with st.form("create_user_form", clear_on_submit=True):
                        new_username = st.text_input("Username")
                        new_password = st.text_input("Password", type="password")
                        new_name = st.text_input("Full Name")
                        new_role = st.selectbox("Role", ["Clinician", "Admin"])
                        create_submitted = st.form_submit_button("Create User")

                        if create_submitted:
                            status_message = create_user(new_username, new_password, new_name, new_role)
                            st.toast(status_message)
                            st.rerun()


# -------------------------------------------------------------
# LAUNCH
# -------------------------------------------------------------
if __name__ == "__main__":
    main()
