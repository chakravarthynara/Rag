from dotenv import load_dotenv
import os
import csv
from typing import List, Dict, Any
from openai import OpenAI
import httpx
import pandas as pd
"""
Agent-based synthetic *cardiology* healthcare data generator (CSV version).

The "agent" is an LLM with a system prompt that:
- Understands the global cardiology domain requirement
- Generates realistic but fully synthetic tabular data
- Outputs CSV rows that we save as CSV files

Prereqs:
    pip install openai python-dotenv httpx

Env:
    .env (in parent folder) should contain:
        OPENAI_API_KEY=...
        # optionally:
        # OPENAI_MODEL=azure/genailab-maas-gpt-4o
"""

# -----------------------------
# ENV + CLIENT CONFIG
# -----------------------------

# Folder structure:
#   Nara_Prac/
#     .env
#     ClinicalAndDrugSystem/
#       SyntheticDataGenerator/
#         synthetic_agent_generator.py

BASE_DIR_FS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_PATH = os.path.join(BASE_DIR_FS, ".env")

# Load .env from parent folder
load_dotenv(ENV_PATH)

API_KEY = os.getenv("OPENAI_API_KEY")
if not API_KEY:
    raise RuntimeError("OPENAI_API_KEY not found in .env")

client = OpenAI(
    api_key=API_KEY,
    # base_url="https://genailab.tcs.in",
    # http_client=httpx.Client(verify=False),
)

# Allow override from env; fallback to your usual Azure model group
MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
print("Using model:", MODEL)

# Where generated CSV files go
BASE_DIR = "data_agent"

# number of rows per table (tune as you like)
N_PATIENTS = 500
N_MED_HISTORY = 1000
N_ALLERGIES = 600
N_CURRENT_MEDS = 1000
N_DRUGS = 150
N_INTERACTIONS = 800
N_CONTRA = 500
N_ALT_DRUGS = 600
N_CLINICAL_RULES = 200
N_SYMPTOMS = 60  # unique symptom concepts
N_ADVERSE_EVENTS = 500

LANGUAGES = ["en", "es", "fr", "hi", "de"]

# -----------------------------
# GLOBAL REQUIREMENT (CARDIOLOGY)
# -----------------------------
GLOBAL_REQUIREMENT = """
You are generating synthetic, fully fake *general medical* health data for an AI research prototype.

Scope (general medical):
- Patient demographics, various risk factors, and a broad medical history across different specialties.
- A wide range of allergies and intolerances to common medications, foods, and environmental factors.
- A wide range of current medications from various classes (e.g., antibiotics, antidepressants, antihypertensives, antidiabetics, analgesics).
- A broad drug master data covering multiple therapeutic areas.
- Drug interaction matrices, contraindications, and alternatives for a wide range of common drugs.
- Clinical guideline-style rules for common conditions across different specialties (e.g., diabetes, asthma, hypertension, depression, infections),
  tagged as if from WHO, FDA, NICE (but text must be synthetic).
- A variety of historical adverse reactions related to different drugs and procedures.
- Multilingual datasets related to a wide range of medical symptoms, conditions, and drug information.
- All data must be HIPAA/GDPR-safe: no real persons, no real chart data, no real guideline text.

Rules:
- Never copy real EHR records or real guideline paragraphs.
- Everything must be obviously synthetic and generic.
- IDs should be consistent (e.g., patient_id used across related tables).
- Use ISO date format YYYY-MM-DD where dates are needed.
"""

# -----------------------------
# UTILS
# -----------------------------
def ensure_dirs():
    """Create category folders under data_agent/."""
    for folder in ["patients", "drugs", "guidelines", "multilingual"]:
        os.makedirs(os.path.join(BASE_DIR, folder), exist_ok=True)


def write_csv(path: str, rows: List[Dict[str, Any]]):
    """Write list of dicts to CSV."""
    os.makedirs(os.path.dirname(path), exist_ok=True)

    if not rows:
        raise ValueError(f"No rows to write for {path}")

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def load_csv(path: str) -> List[Dict[str, Any]]:
    """Load CSV into list of dicts."""
    rows: List[Dict[str, Any]] = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(dict(r))
    return rows


def batched(total: int, size: int) -> List[int]:
    """Split total into batch sizes <= size."""
    batches = []
    remaining = total
    while remaining > 0:
        n = min(size, remaining)
        batches.append(n)
        remaining -= n
    return batches


# -----------------------------
# CORE LLM → CSV GENERATOR
# -----------------------------
def agent_generate_rows(task_desc: str, columns: List[str], n_rows: int) -> List[Dict[str, Any]]:
    """
    Core Agent call using Chat Completions API, but for CSV instead of JSON.

    - Asks model to output ONLY raw CSV (header + rows)
    - Cleans any markdown fences if the model adds them
    - Parses into list[dict] with csv.DictReader
    """

    col_string = ",".join(columns)

    system_prompt = (
        "You are a synthetic cardiology dataset generator. "
        "You always output CLEAN CSV text. "
        "Rules:\n"
        "- First row must be the header with the exact given column names.\n"
        "- Use comma as separator.\n"
        "- No markdown, no explanations, no comments.\n"
        "- Use only ASCII characters. No emojis, no fancy quotes."
    )

    user_prompt = f"""
Global requirement:
{GLOBAL_REQUIREMENT}

Specific dataset task:
{task_desc}

OUTPUT FORMAT (VERY IMPORTANT):
- Return ONLY raw CSV text.
- Do NOT wrap in ``` fences.
- Do NOT add any explanation before or after the CSV.
- Use EXACTLY these columns, in this order, in the first row (header):

{col_string}

- After the header, output exactly {n_rows} data rows.
""".strip()

    resp = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )

    csv_text = (resp.choices[0].message.content or "").strip()

    # Strip possible markdown fences if model ignored instructions
    csv_text = csv_text.replace("```csv", "").replace("```CSV", "").replace("```", "").strip()

    # Try to locate the header line in case model adds some stray text
    lines = [ln for ln in csv_text.splitlines() if ln.strip()]

    header_line = ",".join(columns)
    header_idx = None
    for i, ln in enumerate(lines):
        # Normalize by stripping spaces
        if ln.replace(" ", "") == header_line.replace(" ", ""):
            header_idx = i
            break

    if header_idx is not None:
        lines = lines[header_idx:]  # keep from header onwards

    clean_csv = "\n".join(lines)

    reader = csv.DictReader(clean_csv.splitlines())
    rows = list(reader)

    if len(rows) != n_rows:
        print(f"⚠️ Warning: expected {n_rows} rows, got {len(rows)} for task: {task_desc[:80]}")

    # Ensure all columns exist in each row (fill missing with empty string)
    fixed_rows: List[Dict[str, Any]] = []
    for r in rows:
        fixed = {}
        for col in columns:
            fixed[col] = r.get(col, "").strip() if r.get(col) is not None else ""
        fixed_rows.append(fixed)

    return fixed_rows


# -----------------------------
# PATIENT TABLES
# -----------------------------
def generate_patients() -> List[Dict[str, Any]]:
    path = os.path.join(BASE_DIR, "patients", "patients.csv")

    columns = [
        "patient_id",
        "age",
        "gender",
        "ethnicity",
        "socioeconomic_level",
        "marital_status",
        "disability",
        "country",
        "region",
        "smoker_status",
        "bmi_category",
        "diabetes_status",
        "family_history_cvd",
        "health_risk_score",
    ]

    task_template = """
Generate general synthetic patient demographics for a diverse population.

- patient_id: unique IDs like P00001, P00002, etc.
- age: integer 18–90.
- gender: 'M', 'F', or 'Other'.
- ethnicity: realistic strings like 'White', 'Black', 'Asian', 'Hispanic', 'Other'.
- socioeconomic_level: 'low', 'lower_middle', 'upper_middle', 'high'.
- marital_status: 'single', 'married', 'widowed', 'divorced'.
- disability: 'yes' or 'no'.
- country: realistic codes like 'US', 'IN', 'UK', 'DE', 'BR'.
- region: 'urban', 'semi_urban', 'rural'.
- smoker_status: 'never', 'former', 'current'.
- bmi_category: 'underweight', 'normal', 'overweight', 'obese'.
- diabetes_status: 'none', 'prediabetes', 'type2_diabetes'.
- family_history_cvd: 'yes' or 'no'.
- health_risk_score: A synthetic numerical score from 0.0 to 100.0, where a higher score indicates higher overall health risk. Generate plausible scores based on the patient's age, smoker status, BMI, and diabetes status.
- IMPORTANT: Start numbering patient_id from {start_id}.
"""

    all_rows: List[Dict[str, Any]] = []
    id_counter = 1
    for batch in batched(N_PATIENTS, 50):
        task = task_template.format(start_id=id_counter)
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)
        id_counter += len(rows)

    write_csv(path, all_rows)
    return all_rows


def generate_medical_history(patients: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "patients", "medical_history.csv")
    patient_ids = [p["patient_id"] for p in patients]

    columns = [
        "patient_id",
        "condition_code",
        "condition_name",
        "onset_date",
        "status",
    ]

    task = f"""
Create synthetic general medical history records linked to patients, covering a range of common conditions.

Rules:
- patient_id must be chosen ONLY from this list (you may reuse IDs):
  {patient_ids}
- condition_code: ICD-10-like codes for common conditions such as "I10" (Hypertension), "E11" (Type 2 Diabetes), "J45" (Asthma), "F32" (Depression), "M54.5" (Low back pain).
- condition_name: human-readable condition name matching the code.
- onset_date: between 2005-01-01 and 2023-12-31 (YYYY-MM-DD).
- status: 'active', 'controlled', or 'resolved'.
Some patients should have multiple conditions.
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_MED_HISTORY, 60):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


def generate_allergies(patients: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "patients", "allergies.csv")
    patient_ids = [p["patient_id"] for p in patients]

    columns = [
        "patient_id",
        "allergen",
        "reaction_type",
        "severity",
    ]

    task = f"""
Generate synthetic allergy/intolerance records for a wide range of common allergens.

Rules:
- patient_id: choose only from this list:
  {patient_ids}
- allergen: examples: "Penicillin", "Aspirin", "Sulfa drugs", "Ibuprofen", "Codeine",
  "Peanuts", "Shellfish", "Latex", etc. Synthetic/generic only.
- reaction_type: short phrase like "rash", "swelling", "anaphylaxis", "angioedema", "bradycardia", "hypotension".
- severity: "mild", "moderate", "severe".
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_ALLERGIES, 60):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


def generate_current_medications(patients: List[Dict[str, Any]], drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "patients", "current_medications.csv")
    patient_ids = [p["patient_id"] for p in patients]
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "patient_id",
        "drug_id",
        "drug_name",
        "dose_mg",
        "frequency_per_day",
        "start_date",
    ]

    task = f"""
Create synthetic current medication records linking patients to a variety of common drugs.

Rules:
- patient_id: choose from this list:
  {patient_ids}
- drug_id: choose from this list:
  {drug_ids}
- drug_name: generic drug name matching the drug_id concept (synthetic).
- dose_mg: integer like 2, 5, 10, 20, 40, 80, 100.
- frequency_per_day: 1, 2, or 3.
- start_date: between 2015-01-01 and 2025-12-31 (YYYY-MM-DD).
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_CURRENT_MEDS, 60):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


def generate_adverse_events(patients: List[Dict[str, Any]], drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "patients", "adverse_events.csv")
    patient_ids = [p["patient_id"] for p in patients]
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "event_id",
        "patient_id",
        "drug_id",
        "reaction",
        "serious",
        "onset_date",
        "outcome",
    ]

    task = f"""
Create synthetic historical adverse drug reaction records for a variety of medications.

Rules:
- event_id: unique like AE00001, AE00002, etc.
- patient_id: choose from this list:
  {patient_ids}
- drug_id: choose from this list:
  {drug_ids}
- reaction: synthetic phrases like "Nausea", "Headache", "Dizziness", "Rash", "Hypotension",
  "Serotonin syndrome", "Bleeding", "Hyperkalemia".
- serious: "yes" or "no".
- onset_date: between 2015-01-01 and 2024-12-31 (YYYY-MM-DD).
- outcome: "recovered", "recovering", "not_recovered", "fatal".
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_ADVERSE_EVENTS, 60):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


# -----------------------------
# DRUG TABLES (CARDIOLOGY)
# -----------------------------
def generate_drugs() -> List[Dict[str, Any]]:
    path = os.path.join(BASE_DIR, "drugs", "drugs.csv")

    columns = [
        "drug_id",
        "generic_name",
        "brand_name",
        "atc_code",
        "drug_class",
    ]

    task_template = """
Create synthetic drug master data entries for a wide range of common medications.

Rules:
- drug_id: unique like DRUG001, DRUG002, etc.
- generic_name: plausible synthetic generic name (e.g., "cardiopril", "vasotenol").
- brand_name: synthetic brand name (fake company/product).
- atc_code: pseudo ATC-like code from various classes (e.g., 'C' for cardiovascular, 'N' for nervous system, 'J' for anti-infectives, 'A' for alimentary/metabolism).
- drug_class: one of:
  "ACE inhibitor", "SSRI", "NSAID", "Statin", "Beta blocker", "Antibiotic",
  "Anticoagulant", "Antidiabetic", "Proton-pump inhibitor", "Antihistamine",
  "Corticosteroid", "Opioid analgesic".
- IMPORTANT: Start numbering drug_id from {start_id}.
"""

    all_rows: List[Dict[str, Any]] = []
    id_counter = 1
    for batch in batched(N_DRUGS, 40):
        task = task_template.format(start_id=id_counter)
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)
        id_counter += len(rows)

    write_csv(path, all_rows)
    return all_rows


def generate_drug_interactions(drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "drugs", "drug_interactions.csv")
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "drug_a_id",
        "drug_b_id",
        "interaction_severity",
        "interaction_description",
    ]

    task = f"""
Create synthetic drug-drug interaction records for a variety of common drugs.

Rules:
- drug_a_id and drug_b_id: two different values chosen from this list:
  {drug_ids}
- interaction_severity: "none", "mild", "moderate", "severe".
- interaction_description: short synthetic explanation matching the severity (e.g., "Increased risk of bleeding", "Risk of serotonin syndrome", "Reduced efficacy of drug A").
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_INTERACTIONS, 40):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


def generate_contraindications(drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "drugs", "contraindications.csv")
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "drug_id",
        "condition_code",
        "contraindication_level",
        "notes",
    ]

    task = f"""
Create synthetic drug-condition contraindication records for a variety of drugs and conditions.

Rules:
- drug_id: choose from this list:
  {drug_ids}
- condition_code: pseudo ICD-10-like codes like "I50.0" (Heart Failure), "N18.5" (End-stage renal disease), "K21.9" (GERD), "J45" (Asthma).
- contraindication_level: "caution", "avoid_if_possible", "absolute".
- notes: short synthetic note explaining the contraindication.
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_CONTRA, 60):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


def generate_alternative_drugs(drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "drugs", "alternative_drugs.csv")
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "drug_id",
        "alternative_drug_id",
        "reason",
    ]

    task = f"""
Create synthetic alternative drug mappings for various drug classes.

Rules:
- drug_id: choose from this list:
  {drug_ids}
- alternative_drug_id: different drug_id from the same list.
- reason: one of "same_class", "cheaper", "fewer_side_effects", "guideline_preferred", "renal_safe".
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_ALT_DRUGS, 40):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


# -----------------------------
# GUIDELINE-LIKE RULES (CARDIOLOGY)
# -----------------------------
def generate_clinical_rules():
    path = os.path.join(BASE_DIR, "guidelines", "clinical_rules.csv")

    columns = [
        "rule_id",
        "condition_code",
        "condition_name",
        "rule_type",
        "rule_text",
        "reference_org",
    ]

    task = """
Create synthetic clinical rules inspired by WHO/FDA/NICE style, but completely made-up, for a range of common medical conditions.

Rules:
- rule_id: unique like RULE0001.
- condition_code: pseudo ICD-10-like codes for common conditions (e.g., "I10", "E11", "J45", "F32.9", "M54.5").
- condition_name: readable condition names matching the codes.
- rule_type: "treatment", "screening", "dose_adjustment", "lifestyle".
- rule_text: 1–2 sentence high-level synthetic generic rule text.
- reference_org: "WHO", "FDA", or "NICE".
"""

    all_rows: List[Dict[str, Any]] = []
    for batch in batched(N_CLINICAL_RULES, 40):
        rows = agent_generate_rows(task, columns, batch)
        all_rows.extend(rows)

    write_csv(path, all_rows)


# -----------------------------
# MULTILINGUAL TEXT TABLES (CARDIOLOGY)
# -----------------------------
def generate_multilingual_symptoms():
    path = os.path.join(BASE_DIR, "multilingual", "symptom_phrases_multilingual.csv")

    columns = [
        "symptom_id",
        "language",
        "phrase",
    ]

    task = f"""
Generate synthetic multilingual symptom phrases suitable for patient chat, covering a wide range of common medical symptoms.

Rules:
- Invent {N_SYMPTOMS} distinct symptom concepts in English (e.g., "chest pain", "headache", "cough", "fatigue", "abdominal pain", "dizziness").
- For each symptom, assign symptom_id like SYM001, SYM002, etc.
- For each symptom_id, create one row per language: {LANGUAGES}.
- language: one of {LANGUAGES}.
- phrase: short patient-style symptom phrase in that language.
- Hindi can be in Latin script (e.g., "seene mein dard").
- Output one row per (symptom_id, language).
Total rows = {N_SYMPTOMS} * {len(LANGUAGES)} = {N_SYMPTOMS * len(LANGUAGES)}.
"""

    total_rows = N_SYMPTOMS * len(LANGUAGES)
    rows = agent_generate_rows(task, columns, total_rows)

    write_csv(path, rows)


def generate_multilingual_conditions():
    path = os.path.join(BASE_DIR, "multilingual", "condition_names_multilingual.csv")

    columns = [
        "condition_code",
        "language",
        "name_translation",
    ]

    num_conditions = 15

    task = f"""
Create synthetic medical condition names in multiple languages.

Rules:
- Generate about {num_conditions} pseudo ICD-10-like condition codes and English names for common conditions:
  synthetic variants of hypertension, diabetes, asthma, depression, migraine, arthritis, etc.
- For each condition_code, create one row per language: {LANGUAGES}.
- language: one of {LANGUAGES}.
- name_translation: cardiovascular condition name/translation in that language.
Total rows = {num_conditions} * {len(LANGUAGES)} = {num_conditions * len(LANGUAGES)}.
"""

    total_rows = num_conditions * len(LANGUAGES)
    rows = agent_generate_rows(task, columns, total_rows)

    write_csv(path, rows)


def generate_multilingual_drug_info(drugs: List[Dict[str, Any]]):
    path = os.path.join(BASE_DIR, "multilingual", "drug_info_multilingual.csv")
    drug_ids = [d["drug_id"] for d in drugs]

    columns = [
        "drug_id",
        "language",
        "description_text",
    ]

    task = f"""
Create synthetic multilingual drug descriptions for a variety of common drugs.

Rules:
- Use these drug_ids: {drug_ids}
- For each drug_id, create one row per language: {LANGUAGES}.
- language: one of {LANGUAGES}.
- description_text: 1–2 sentence simple layperson explanation of what the drug does
  (e.g., "helps lower blood pressure", "is an antibiotic to treat infections", "helps manage blood sugar") – synthetic only.
Total rows = {len(drug_ids)} * {len(LANGUAGES)} = {len(drug_ids) * len(LANGUAGES)}.
"""

    total_rows = len(drug_ids) * len(LANGUAGES)
    rows = agent_generate_rows(task, columns, total_rows)

    write_csv(path, rows)


# -----------------------------
# MAIN AGENT WORKFLOW
# -----------------------------
def main():
    ensure_dirs()

    print("🔹 Agent: generating general drug master...")
    drugs = generate_drugs()

    print("🔹 Agent: generating diverse patient demographics...")
    patients = generate_patients()
    print("🔹 Loading existing drug master from CSV...")
    # drugs_path = os.path.join(BASE_DIR, "drugs", "drugs.csv")
    # drugs = load_csv(drugs_path)

    print("🔹 Loading existing patients from CSV...")
    # patients_path = os.path.join(BASE_DIR, "patients", "patients.csv")
    # patients = load_csv(patients_path)
    print("🔹 Agent: generating general medical history...")
    generate_medical_history(patients)

    print("🔹 Agent: generating common allergies...")
    generate_allergies(patients)

    print("🔹 Agent: generating current medications...")
    generate_current_medications(patients, drugs)

    print("🔹 Agent: generating adverse events...")
    generate_adverse_events(patients, drugs)

    print("🔹 Agent: generating drug interactions...")
    generate_drug_interactions(drugs)

    print("🔹 Agent: generating contraindications...")
    generate_contraindications(drugs)

    print("🔹 Agent: generating alternative drugs...")
    generate_alternative_drugs(drugs)

    print("🔹 Agent: generating general clinical rules...")
    generate_clinical_rules()

    print("🔹 Agent: generating multilingual medical symptoms...")
    generate_multilingual_symptoms()

    print("🔹 Agent: generating multilingual medical conditions...")
    generate_multilingual_conditions()

    print("🔹 Agent: generating multilingual drug info...")
    generate_multilingual_drug_info(drugs)

    print("✅ Done! Synthetic *general medical* agent-generated CSV datasets are in ./data_agent/")


if __name__ == "__main__":
    main()
