"""
train_risk_model.py

This script trains a simple machine learning model to predict the 'health_risk_score'
based on patient demographics from the synthetic dataset.

It performs feature engineering, trains a Ridge regression model, and saves the
trained model pipeline using joblib for later use in a model serving API.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error
import joblib
import os

# Define paths
MODEL_DIR = os.path.dirname(__file__)
SYNTHETIC_DATA_DIR = os.path.dirname(MODEL_DIR)
DATA_PATH = os.path.join(SYNTHETIC_DATA_DIR, "data_agent", "patients", "patients.csv")
MODEL_PATH = os.path.join(MODEL_DIR, "health_risk_model.pkl")

def train_model():
    """Loads data, trains the model, and saves it."""
    print("Loading patient data...")
    try:
        df = pd.read_csv(DATA_PATH)
    except FileNotFoundError:
        print(f"ERROR: Data file not found at {DATA_PATH}")
        print("Please run synthetic_agent_generator.py first to create the dataset.")
        return

    print("Preparing data for training...")
    # Define features and target
    features = ['age', 'gender', 'smoker_status', 'bmi_category', 'diabetes_status', 'family_history_cvd']
    categorical_features = ['gender', 'smoker_status', 'bmi_category', 'diabetes_status', 'family_history_cvd']
    numerical_features = ['age']
    target = 'health_risk_score'

    # Drop rows with missing target
    df.dropna(subset=[target], inplace=True)
    df[target] = pd.to_numeric(df[target])

    X = df[features]
    y = df[target]

    # Create a preprocessor for categorical features
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', 'passthrough', numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
        ])

    # Create the model pipeline
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', Ridge(alpha=1.0))
    ])

    # Split data and train
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    print("Training the model...")
    model_pipeline.fit(X_train, y_train)

    # Evaluate and save
    mse = mean_squared_error(y_test, model_pipeline.predict(X_test))
    print(f"Model training complete. Mean Squared Error: {mse:.2f}")
    joblib.dump(model_pipeline, MODEL_PATH)
    print(f"Model saved to {MODEL_PATH}")

if __name__ == "__main__":
    train_model()