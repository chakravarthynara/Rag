"""
mcp_server.py (Model Serving Server)

A simple FastAPI server to host the trained health risk prediction model.
It exposes a /predict endpoint that takes patient demographics and returns a risk score.

To run:
  uvicorn ml_model.mcp_server:app --reload
"""

import joblib
import pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel
import os

# Define paths
# Go up one level from 'mcp_server' to the main 'SyntheticDataGenerator' directory
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "ml_model", "health_risk_model.pkl")

# --- Pydantic Model for Input Validation ---
class PatientFeatures(BaseModel):
    age: int
    gender: str
    smoker_status: str
    bmi_category: str
    diabetes_status: str
    family_history_cvd: str


app = FastAPI(
    title="Clinical Risk Model Server",
    description="An API to serve a trained ML model for health risk prediction.",
    version="1.0.0"
)

# --- Load Model ---
try:
    model = joblib.load(MODEL_PATH)
    print("✅ Model loaded successfully.")
except FileNotFoundError:
    print(f"❌ ERROR: Model file not found at {MODEL_PATH}. Please run train_risk_model.py first.")
    model = None


@app.post("/predict")
def predict_risk(features: PatientFeatures):
    """
    Predicts the health risk score based on patient features.
    """
    if model is None:
        return {"error": "Model is not loaded. Please check server logs."}

    # Convert input data to a DataFrame that the model pipeline expects
    input_df = pd.DataFrame([features.dict()])
    
    prediction = model.predict(input_df)
    risk_score = round(prediction[0], 2)

    return {"risk_topic": "ML-based Health Risk Score", "risk_score": risk_score}